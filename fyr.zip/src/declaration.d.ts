declare module '*.png';
declare module '*.webp';
declare module '*.md';
